# Galeria Presidencial — RPG de Brasil (v2)

Site estático responsivo para GitHub Pages. Inclui:
- Galeria geral com pesquisa e filtros por temporada/partido
- Página de índice de temporadas (`temporadas.html`)
- Página de cada temporada por consulta (`temporada.html?nome=Temporada%20I`)
- Fichas com partido, eleição/resultado, biografia, retrato, vice-presidente e governo/ministros
- Design histórico inspirado em arquivos e museus

## Publicação gratuita
1. Descarregue e extraia o ZIP no seu dispositivo.
2. Entre em https://github.com/ ou crie uma conta.
3. Abra https://github.com/new e crie um repositório chamado `galeria-presidencial`.
4. Escolha **Public**. Para GitHub Pages gratuito, um repositório público é o caminho mais simples.
5. Dentro do repositório, use **Add file → Upload files** e carregue os ficheiros deste pacote: `index.html`, `temporadas.html`, `temporada.html`, `presidentes.js`, `README.md`.
6. Clique em **Commit changes** para guardar.
7. Abra **Settings → Pages**.
8. Em **Build and deployment**, escolha **Deploy from a branch**.
9. Selecione branch `main` e pasta `/ (root)`, depois **Save**.
10. Aguarde alguns minutos. O endereço será apresentado em Settings → Pages, geralmente `https://SEU-USUARIO.github.io/galeria-presidencial/`.

## Como adicionar fotografias
1. Dentro do repositório, crie uma pasta chamada `imagens` (pode criar localmente e carregá-la junto com os ficheiros).
2. Coloque lá os retratos, por exemplo `presidente-01.jpg`.
3. No ficheiro `presidentes.js`, preencha o campo: `foto: "imagens/presidente-01.jpg"`.
4. Use imagens que a comunidade tem direito de publicar. Evite links temporários de anexos ou CDN do Discord.

## Como editar os dados
Edite `presidentes.js`. Cada presidente é um objeto. Copie um bloco para criar um novo, atribua um `id` único e preencha os campos.
O valor `temporada` deve ser escrito exatamente igual em todos os presidentes da mesma temporada, por exemplo `"Temporada I"`.

## Dar acesso à equipa
1. Abra o repositório no GitHub.
2. Vá a **Settings → Collaborators** (em algumas interfaces, **Collaborators and teams**).
3. Clique em **Add people**.
4. Procure o nome de utilizador ou email associado à conta GitHub de cada membro da equipa e envie o convite.
5. Cada pessoa precisa aceitar o convite. Conceda acesso apenas a pessoas de confiança, porque colaboradores com permissão de escrita podem alterar ou apagar ficheiros.
6. A equipa pode editar `presidentes.js` diretamente no navegador: abra o ficheiro, clique no lápis (**Edit this file**), faça as alterações e clique em **Commit changes**.

## Limitações importantes
- Este site não tem login próprio nem painel de administração.
- As alterações são feitas no GitHub. O site público mostra os dados publicados no repositório.
- Um site público pode ser visto por qualquer pessoa; não publique dados privados.
- O GitHub Pages é gratuito para sites estáticos em repositórios públicos dentro dos limites do serviço.
