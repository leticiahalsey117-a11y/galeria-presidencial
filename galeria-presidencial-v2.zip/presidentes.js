/*
GALERIA PRESIDENCIAL — DADOS
Edite os exemplos abaixo ou substitua-os pelos registos do seu RPG.
Para adicionar um presidente, copie um objeto inteiro e altere o id.
FOTOGRAFIAS: crie uma pasta "imagens" no repositório e use um caminho como "imagens/nome.jpg".
Não deixe dois presidentes com atual: true. Use true apenas para o atual.
*/
window.PRESIDENTES = [
  {
    id: 1,
    nome: "Nome do Presidente",
    partido: "Partido",
    temporada: "Temporada I",
    mandato: "AAAA–AAAA",
    eleicao: "Vitória eleitoral — resultado a registar",
    vice: "Nome do vice-presidente",
    governo: "Registe aqui o primeiro-ministro (se aplicável), os ministros e a composição do governo.",
    atual: true,
    situacao: "Presidente em exercício",
    foto: "",
    resumo: "Breve apresentação do mandato e do contexto político.",
    biografia: "Registe aqui a trajetória política, as eleições, a posse e os principais momentos da vida pública deste presidente no universo do RPG.",
    realizacoes: "Registe aqui reformas, crises, decisões históricas, decretos e outros acontecimentos importantes."
  },
  {
    id: 2,
    nome: "Nome da Presidente",
    partido: "Partido",
    temporada: "Temporada II",
    mandato: "AAAA–AAAA",
    eleicao: "Resultado eleitoral a registar",
    vice: "Nome do vice-presidente",
    governo: "Composição do governo e nomes dos ministros.",
    atual: false,
    situacao: "Mandato concluído",
    foto: "",
    resumo: "Breve apresentação do mandato.",
    biografia: "Biografia e trajetória política da presidente no RPG.",
    realizacoes: "Acontecimentos importantes do mandato."
  }
];
